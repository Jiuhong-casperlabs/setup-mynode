Build for Ubuntu 18.04.

To run on other platforms, build from https://github.com/CasperLabs/casper-node
 cd node
 cargo build --release

git commit hash: 4f9a59e800a75494b098b19d8da70b50456dd81b
